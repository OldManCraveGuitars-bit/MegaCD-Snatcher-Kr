/* Core-private ink consumer. No game RAM, SAT, VRAM or CRAM writes.
 * Assets and controls belong to the same generated product input graph.
 * Marker 0x48 follows the legacy ROM page clock. Marker 0x49 publishes a
 * playback-request generation, directory and caption-table address.  The
 * script module can change while the previous module's voice is still playing;
 * the published table, not the current screen's script module, owns its ink.
 * A request is not audible PCM:
 * this read-only consumer arms that identity, starts only on the stock
 * $1511E bit-1 playback edge used by every registered mode 2/82 voice, and
 * retires on the matching falling edge. Neither path writes game state.
 */
#ifndef KR_HOST_CAPTION_OVERLAY_H
#define KR_HOST_CAPTION_OVERLAY_H
#include "kr_host_caption_assets.h"
#include "kr_host_ending_quote_assets.h"

/* The ending card is original written screen text, not a PCM voice.  Observe
 * the completed host framebuffer and replace its five rows in source order.
 * This neither changes game script/VRAM nor any voice caption. */
static unsigned int kr_host_ending_quote_context;
static const unsigned char *kr_host_frame_payload;
static const unsigned char *kr_host_frame_cdda_payload;

static unsigned int kr_host_ending_quote_match_row(
  unsigned int row, const unsigned char *framebuffer, unsigned int pitch)
{
  unsigned int x;
  const PIXEL_OUT_T *out = (const PIXEL_OUT_T *)(framebuffer +
    kr_host_ending_quote_source_y[row] * pitch);
  PIXEL_OUT_T black = MAKE_PIXEL(0,0,0);
  if (out[0] != black || out[8] != black ||
      out[240] != black || out[255] != black)
    return 0;
  for (x = 0; x < KR_HOST_ENDING_QUOTE_MASK_WIDTH; ++x)
  {
    unsigned int actual = out[KR_HOST_ENDING_QUOTE_MASK_X + x] != black;
    unsigned int expected =
      (kr_host_ending_quote_source_mask[row][x >> 3] >> (7 - (x & 7))) & 1;
    if (actual != expected) return 0;
  }
  return 1;
}

static void kr_host_ending_quote_finished_frame(
  unsigned char *framebuffer, unsigned int pitch)
{
  unsigned int row, y, x, visible_rows = 0;
  if (!kr_host_ending_quote_context ||
      kr_host_frame_payload || kr_host_frame_cdda_payload)
    return;
  for (row = 0; row < KR_HOST_ENDING_QUOTE_LINE_COUNT; ++row)
  {
    if (kr_host_ending_quote_match_row(row, framebuffer, pitch))
      visible_rows = row + 1;
  }
  /* Native evidence has a 2+2+1 reveal.  A lower row can be freshly drawn
   * while the upper rows survive only in the host framebuffer.  Reconstruct
   * the complete observed stage from its highest matching source row.  If
   * the original card blinks to black, no signature matches and we paint none. */
  if (!visible_rows) return;
  if (visible_rows < 5) visible_rows = visible_rows <= 2 ? 2 : 4;
  for (row = 0; row < visible_rows; ++row)
  {
    for (y = 0; y < 16; ++y)
    {
      PIXEL_OUT_T *dst = (PIXEL_OUT_T *)(framebuffer +
        (kr_host_ending_quote_source_y[row] + y) * pitch);
      for (x = 24; x < 232; ++x) dst[x] = MAKE_PIXEL(0,0,0);
      for (x = 0; x < KR_HOST_ENDING_QUOTE_PIXEL_WIDTH; ++x)
      {
        unsigned int value = kr_host_ending_quote_pixels[
          row * KR_HOST_ENDING_QUOTE_ROW_BYTES +
          y * (KR_HOST_ENDING_QUOTE_PIXEL_WIDTH / 2) + x / 2];
        unsigned int ink = (x & 1) ? (value & 15) : (value >> 4);
        if (ink == 1) dst[24 + x] = MAKE_PIXEL(15,15,15);
        else if (ink == 7) dst[24 + x] = MAKE_PIXEL(0,0,0);
      }
    }
  }
}

static unsigned int kr_host_read_word(const unsigned char *ram, unsigned int offset, unsigned int byte_xor)
{
  return ((unsigned int)ram[offset ^ byte_xor] << 8) | ram[(offset + 1) ^ byte_xor];
}

static const unsigned char *kr_host_current_page(const unsigned char *ram, unsigned int byte_xor)
{
  unsigned int i, module, directory, page, payload, table;
  if (ram[0x27f0f ^ byte_xor] != 0x48 ||
      kr_host_read_word(ram, 0x27f0a, byte_xor) != 0x4b53)
    return 0;
  directory = ram[0x27f13 ^ byte_xor];
  if (kr_host_read_word(ram, 0x27f08, byte_xor) != (0xa500 | directory))
    return 0;
  module = kr_host_read_word(ram, 0x980c, byte_xor);
  if (module < 0x39) return 0;
  /* SCRIPT_NAMES uses decimal names: observed SP37 index 0x5e -> 37, not 0x37. */
  module -= 0x39;
  page = ram[0x27f05 ^ byte_xor];
  payload = kr_host_read_word(ram, 0x27f14, byte_xor);
  table = (kr_host_read_word(ram, 0x1dff8, byte_xor) << 16) |
           kr_host_read_word(ram, 0x1dffa, byte_xor);
  for (i = 0; i < KR_HOST_MODULE_COUNT; ++i)
  {
    const kr_host_module_t *m = kr_host_modules + i;
    if (m->module != module) continue;
    if (m->ownership_address && ram[m->ownership_address ^ byte_xor] != 0xa5)
      return 0;
    if (table != m->table_address || directory >= m->directories ||
        page >= m->counts[directory] ||
        ram[0x27f04 ^ byte_xor] != m->counts[directory] ||
        payload >= m->pages || payload != m->offsets[directory] + page)
      return 0;
    return m->pixels + payload * 1280;
  }
  return 0;
}

/* A page is immutable core-owned data. Take one identity snapshot before an
 * emulated frame, not one per scanline: game voice controls can change between
 * two scanlines. The next frame observes start/page/end changes in full.
 * This pointer is presentation state only, never written into a save or game RAM.
 */
/* Act2 recap pages use a separate, read-only CD sector clock. The bitmap
 * bank is generated into kr_host_caption_assets.h from the audited draft. */
typedef struct {
  int index, lba, track_start, track_end, track_type;
  unsigned int status, pending, latency, mute;
} kr_host_cdda_state_t;
static unsigned int kr_host_opening_track_active;
static unsigned int kr_host_clock_active;
static unsigned int kr_host_clock_armed;
static unsigned int kr_host_clock_retired;
static unsigned int kr_host_clock_module;
static unsigned int kr_host_clock_directory;
static unsigned int kr_host_clock_generation;
static unsigned int kr_host_clock_age;
static unsigned int kr_host_pcm_playing_previous;

static void kr_host_clock_clear(void)
{
  kr_host_clock_active = 0;
  kr_host_clock_armed = 0;
  kr_host_clock_retired = 0;
  kr_host_clock_age = 0;
}

static const unsigned char *kr_host_audio_clock_page(
  const unsigned char *ram, unsigned int byte_xor,
  unsigned int pcm_playing, unsigned int pcm_rising)
{
  unsigned int i, directory, generation, table, page, payload, identity_changed;
  const kr_host_module_t *m;
  if (ram[0x27f0f ^ byte_xor] != 0x49 ||
      kr_host_read_word(ram, 0x27f0a, byte_xor) != 0x4b53)
  {
    kr_host_clock_clear();
    return 0;
  }
  directory = ram[0x27f13 ^ byte_xor];
  if (kr_host_read_word(ram, 0x27f08, byte_xor) != (0xa500 | directory))
  {
    kr_host_clock_clear();
    return 0;
  }
  generation = ram[0x27f0e ^ byte_xor];
  table = (kr_host_read_word(ram, 0x1dff8, byte_xor) << 16) |
           kr_host_read_word(ram, 0x1dffa, byte_xor);
  for (i = 0; i < KR_HOST_MODULE_COUNT; ++i)
  {
    m = kr_host_modules + i;
    if (m->table_address != table) continue;
    if (m->ownership_address && ram[m->ownership_address ^ byte_xor] != 0xa5)
    {
      kr_host_clock_clear();
      return 0;
    }
    if (directory >= m->directories ||
      ram[0x27f04 ^ byte_xor] != m->counts[directory])
    {
      kr_host_clock_clear();
      return 0;
    }
    identity_changed = !kr_host_clock_armed || kr_host_clock_module != m->module ||
        kr_host_clock_directory != directory ||
        kr_host_clock_generation != generation;
    if (identity_changed)
    {
      kr_host_clock_age = 0;
      kr_host_clock_active = 0;
      kr_host_clock_retired = 0;
      kr_host_clock_armed = 1;
      kr_host_clock_module = m->module;
      kr_host_clock_directory = directory;
      kr_host_clock_generation = generation;
      if (!pcm_rising)
        return 0;
      kr_host_clock_active = 1;
    }
    else if (kr_host_clock_retired)
    {
      return 0;
    }
    else if (!kr_host_clock_active)
    {
      if (!pcm_rising)
        return 0;
      kr_host_clock_active = 1;
      kr_host_clock_age = 0;
    }
    else if (!pcm_playing)
    {
      kr_host_clock_active = 0;
      kr_host_clock_retired = 1;
      return 0;
    }
    else if (kr_host_clock_age < 0xffff)
    {
      ++kr_host_clock_age;
    }
    /* The PCM playing bit can remain high for buffered tail frames after
     * the authored voice has ended.  Keep the falling edge as the early
     * removal path, but do not display a caption beyond its compiled voice
     * duration when a short clip leaves the hardware request latched. */
    if (kr_host_clock_age >= m->ends[directory])
    {
      kr_host_clock_active = 0;
      kr_host_clock_retired = 1;
      return 0;
    }
    payload = m->offsets[directory];
    page = 0;
    while (page + 1 < m->counts[directory] &&
           m->starts[payload + page + 1] <= kr_host_clock_age)
      ++page;
    payload += page;
    if (payload >= m->pages)
    {
      kr_host_clock_clear();
      return 0;
    }
    return m->pixels + payload * 1280;
  }
  kr_host_clock_clear();
  return 0;
}

static const unsigned char *kr_host_cdda_page(
  const unsigned char *ram, unsigned int byte_xor,
  const kr_host_cdda_state_t *drive)
{
  unsigned int i, relative;
  (void)ram;
  (void)byte_xor;
  if (!drive || drive->status != 1 || drive->pending || drive->latency ||
      drive->mute || drive->track_type != 0 || drive->lba < drive->track_start)
    return 0;

#ifdef KR_OPENING_PAGE_COUNT
  if (drive->index == 2 && drive->track_start == 56659 &&
      drive->track_end == 66629)
  {
    kr_host_opening_track_active = 1;
    relative = (unsigned int)(drive->lba - drive->track_start);
    for (i = 0; i < KR_OPENING_PAGE_COUNT; ++i)
    {
      const kr_opening_page_t *page = &kr_opening_pages[i];
      if (relative >= page->first_sector && relative < page->end_sector)
        return kr_opening_pixels + i * 960;
    }
    return 0;
  }
#endif

#ifdef KR_FAREWELL_PAGE_COUNT
  if (drive->index == 3 && drive->track_start == 66779 &&
      drive->track_end == 87184)
  {
    relative = (unsigned int)(drive->lba - drive->track_start);
    for (i = 0; i < KR_FAREWELL_PAGE_COUNT; ++i)
    {
      const kr_farewell_page_t *page = &kr_farewell_pages[i];
      if (relative >= page->first_sector && relative < page->end_sector)
      {
        /* Only the missing words take host priority. Outside these windows,
         * the existing 25 D0 captions continue through the native path. */
        kr_host_opening_track_active = 1;
        return kr_farewell_pixels + i * 960;
      }
    }
    return 0;
  }
#endif

#ifdef KR_ACT2_RECAP_PAGE_COUNT
  if (!((drive->index == 7 && drive->track_start == 106833 &&
         drive->track_end == 122773) ||
        (drive->index == 8 && drive->track_start == 122923 &&
         drive->track_end == 129326)))
    return 0;
  relative = (unsigned int)(drive->lba - drive->track_start);
  for (i = 0; i < KR_ACT2_RECAP_PAGE_COUNT; ++i)
  {
    const kr_act2_recap_page_t *page = &kr_act2_recap_pages[i];
    if (page->track_number == (unsigned int)drive->index + 1 &&
        relative >= page->first_sector && relative < page->end_sector)
      return kr_act2_recap_pixels + i * 960;
  }
#endif
  return 0;
}

static void kr_host_begin_frame_with_cdda(const unsigned char *ram, unsigned int byte_xor,
                                          const kr_host_cdda_state_t *drive)
{
  unsigned int pcm_playing, pcm_rising;
  kr_host_frame_cdda_payload = 0;
  kr_host_opening_track_active = 0;
  kr_host_ending_quote_context = 0;
  if (!ram)
  {
    kr_host_frame_payload = 0;
    kr_host_clock_clear();
    kr_host_pcm_playing_previous = 0;
    return;
  }
  pcm_playing = (ram[0x1511e ^ byte_xor] & 0x02) != 0;
  pcm_rising = pcm_playing && !kr_host_pcm_playing_previous;
  kr_host_ending_quote_context =
    !pcm_playing && kr_host_read_word(ram, 0x980c, byte_xor) == 0x5f;
  kr_host_frame_cdda_payload = kr_host_cdda_page(ram, byte_xor, drive);
  if (kr_host_opening_track_active)
  {
    kr_host_frame_payload = 0;
    kr_host_pcm_playing_previous = pcm_playing;
    return;
  }
  if (ram[0x27f0f ^ byte_xor] == 0x49)
  {
    kr_host_frame_cdda_payload = 0; /* preserve r177 PCM priority outside Track03 */
    kr_host_frame_payload = kr_host_audio_clock_page(
      ram, byte_xor, pcm_playing, pcm_rising);
    kr_host_pcm_playing_previous = pcm_playing;
    return;
  }
  kr_host_clock_clear();
  if (kr_host_frame_cdda_payload)
  {
    kr_host_frame_payload = 0;
    kr_host_pcm_playing_previous = pcm_playing;
    return;
  }
  kr_host_frame_payload = kr_host_current_page(ram, byte_xor);
  kr_host_pcm_playing_previous = pcm_playing;
}

/* Preserve the original two-argument entry for existing PCM consumers. */
static void kr_host_begin_frame(const unsigned char *ram, unsigned int byte_xor)
{
  kr_host_begin_frame_with_cdda(ram, byte_xor, 0);
}

static void kr_host_overlay_line(const unsigned char *payload, int line, unsigned char *out, int width)
{
  int x, y = line - 198;
  if (!payload || y < 0 || y >= 16) return;
  for (x = 0; x < 160 && x + 48 < width; ++x)
  {
    int tile = (y / 8) * 20 + x / 8;
    unsigned int value = payload[tile * 32 + (y & 7) * 4 + (x & 7) / 2];
    unsigned int ink = (x & 1) ? (value & 15) : (value >> 4);
    if (ink == 1) out[x + 48] = 0xfe;
    else if (ink == 7) out[x + 48] = 0xff;
  }
}

static void kr_host_overlay_frame_line(int line, unsigned char *out, int width)
{
  if (kr_host_frame_cdda_payload)
  {
    int x, y = line - 192;
    if (y < 0 || y >= 24) return;
    for (x = 0; x < 160 && x + 48 < width; ++x)
    {
      int tile = (y / 8) * 20 + x / 8;
      unsigned int packed = kr_host_frame_cdda_payload[
        tile * 16 + (y & 7) * 2 + (x & 7) / 4];
      unsigned int ink = (packed >> (6 - 2 * (x & 3))) & 3;
      if (ink == 1) out[x + 48] = 0xfe;
      else if (ink == 2) out[x + 48] = 0xff;
    }
    return;
  }
  kr_host_overlay_line(kr_host_frame_payload, line, out, width);
}
#endif
