{
   global: chd_*;
   local: *;
};

